function renderPosts(boston, container) {
  const people = boston.data;
  people.sort((a,b)=>b[11]-a[11]);
  var filteredPeople = people.filter(x => x[11]> 200000);

  
    

  let html = '';
  for (let i = 0; i < 6; i++) {
    html +=
      '<li class="topSalaries">' + '<h2>' + people[i][8] + '</h2>' + '<h3>' + people[i][11] + '</h3>';
  }
  

  for (let i = 0; i<filteredPeople.length; i++){
    html += 
      '<li class="topEmployees">' + '<h2>' + filteredPeople[i][8] + '</h2>' + '<h3>' + filteredPeople[i][11] + '</h3>';
  }


  container.innerHTML = "<ul>" +html+ "</ul>";

}  




  // TODO: add code to display the html variable inside a ul element with id="data"
  // Hint: you can use the container parameter's innerHTML property to insert Html tags

renderPosts(boston, document.getElementById('container'));

var b = renderPosts(boston, document.getElementById('container'));
